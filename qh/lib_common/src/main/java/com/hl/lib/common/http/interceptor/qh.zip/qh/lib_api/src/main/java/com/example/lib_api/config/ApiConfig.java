package com.example.lib_api.config;

public class ApiConfig {
      public static final   String BASE_URL = "https://api.jisuapi.com/";
      public static final   String BASE_URL_HTTPS_NAME = "https";
      public static final   String BASE_URL_HTTPS = "https://www.baidu.com/";
      public static final  int SUCCESS_CODE = 0;
}
