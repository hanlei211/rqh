package com.hl.lib.common.Interface;

public interface INetErrView {
    //显示网络错误的View
     void showNetErrView();
    //隐藏网络错误的View
     void hideNetErrView();
}
