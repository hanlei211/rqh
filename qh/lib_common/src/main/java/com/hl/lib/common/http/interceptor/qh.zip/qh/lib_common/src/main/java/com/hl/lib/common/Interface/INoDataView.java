package com.hl.lib.common.Interface;

public interface INoDataView {

    //显示无数据的view
    void showNoDataView();
    //隐藏无数据view
    void hideNoDataView();
}
