package com.hl.lib.common.base;

/**
 * des:baseModel

 */
public interface BaseModel {
}
