package com.hl.lib.common.baseapp;

public class AppConfig {

    public static final String DEBUG_TAG = "logger";// LogCat的标记
    public static final String  BASE_URL="https://api.jisuapi.com/";    //基础数据访问网站
    public static final String  APP_KEY = "085e062fb4798457";  //新闻网站访问接口
}
