package com.hl.lib.common.contract;

public class BaseContract {
}
