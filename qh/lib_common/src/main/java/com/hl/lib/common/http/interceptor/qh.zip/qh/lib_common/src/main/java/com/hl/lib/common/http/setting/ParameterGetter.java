package com.hl.lib.common.http.setting;

/**
 * 描述：
 *
 */
public interface ParameterGetter {
    String get();
}
