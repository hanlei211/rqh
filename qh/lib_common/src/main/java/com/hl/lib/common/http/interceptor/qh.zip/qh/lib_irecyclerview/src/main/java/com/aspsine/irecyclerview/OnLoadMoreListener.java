package com.aspsine.irecyclerview;

import android.view.View;

/**
 * Created by aspsine on 16/3/13.
 */
public interface OnLoadMoreListener {

    void onLoadMore(View loadMoreView);

}
