package com.aspsine.irecyclerview;

/**
 * Created by aspsine on 16/3/13.
 */
public interface OnRefreshListener {
    void onRefresh();
}
