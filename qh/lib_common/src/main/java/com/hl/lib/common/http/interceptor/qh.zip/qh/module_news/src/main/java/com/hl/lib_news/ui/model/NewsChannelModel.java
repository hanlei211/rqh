package com.hl.lib_news.ui.model;


import com.hl.lib_news.ui.contract.NewsChannelContract;


public class NewsChannelModel implements NewsChannelContract.Model {

}
