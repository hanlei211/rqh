package com.hl.lib_news.ui.model;


import com.hl.lib_news.ui.contract.NewsListContract;


public class NewsListModel implements NewsListContract.Model{

}
