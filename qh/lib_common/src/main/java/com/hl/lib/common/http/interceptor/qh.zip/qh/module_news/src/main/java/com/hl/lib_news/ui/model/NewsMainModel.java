package com.hl.lib_news.ui.model;


import com.hl.lib_news.ui.contract.NewMainContract;


public class NewsMainModel  implements NewMainContract.Model {

}
