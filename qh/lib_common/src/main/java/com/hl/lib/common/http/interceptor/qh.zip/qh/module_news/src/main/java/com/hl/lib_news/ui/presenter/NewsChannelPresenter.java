package com.hl.lib_news.ui.presenter;

import com.hl.lib_news.ui.contract.NewsChannelContract;

public class NewsChannelPresenter extends NewsChannelContract.Presenter {
}
